import boto3, os, json

def handler(event, context):
    action = event.get("action", "status")
    ec2 = boto3.client("ec2")
    rds = boto3.client("rds")
    instance_id = os.environ["EC2_INSTANCE_ID"]
    db_id = os.environ["RDS_INSTANCE_ID"]

    if action == "start":
        ec2.start_instances(InstanceIds=[instance_id])
        rds.start_db_instance(DBInstanceIdentifier=db_id)
    elif action == "stop":
        ec2.stop_instances(InstanceIds=[instance_id])
        rds.stop_db_instance(DBInstanceIdentifier=db_id)

    return {"statusCode": 200, "body": json.dumps({"action": action})}
